<div class="ads">
    <div class="ads-margin">
        <?php if ($enable_ads): ?>
            <div class="ads-title">
                Advertisement
            </div>
        <?php endif; ?>
        <div class="ads" style="width: 768px; height:90px;">
            <?php if ($enable_ads) include 'ads/768x90.php'; ?>
        </div>
    </div>
</div>
