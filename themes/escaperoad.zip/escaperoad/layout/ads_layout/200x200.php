<div class="ads">
    <div class="ads-margin">
        <?php if ($enable_ads): ?>
            <div class="ads-title">
                Advertisement
            </div>
        <?php endif; ?>
        <div class="ads" style="width: 200px; height:200px;">
            <?php if ($enable_ads) include 'ads/200x200.php'; ?>
        </div>
    </div>
</div>
