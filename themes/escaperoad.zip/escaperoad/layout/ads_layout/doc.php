<div class="ads">
    <div class="ads-margin">
        <?php if ($enable_ads) : ?>
            <div class="ads-title">
                Advertisement
            </div>
        <?php endif; ?>
        <div class="ads-doc">
            <?php if ($enable_ads) include 'ads/doc.php'; ?>
        </div>
    </div>
</div>