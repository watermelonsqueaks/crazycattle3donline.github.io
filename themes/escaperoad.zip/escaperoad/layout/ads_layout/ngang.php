<div class="ads">
    <div class="ads-margin">
        <?php if ($enable_ads) : ?>
            <div class="ads-title">
                Advertisement
            </div>
        <?php endif; ?>
        <div class="ads-ngang">
            <?php if ($enable_ads) include 'ads/ngang.php'; ?>
        </div>
    </div>
</div>